/*************************************************
 * File: LinkedLists.cpp
 *
 * Our very first program using Linked Lists! :-D
 */

#include <iostream>
#include <string>
#include "simpio.h"
#include "console.h"
using namespace std;

/* Type: Cell
 *
 * A cell in a linked list.
 */
struct Cell {
	string value;
	Cell* next;
};

/* Recursive function to print a linked list. */
void printList(Cell* list) {
    /* Base case: If the list is empty, there's nothing to print. */
    if (list == nullptr) return;

    /* Recursive case: If the list has at least one cell, print that cell,
     * then print the remaining items in the list.
     */
    cout << list->value << endl;
    printList(list->next);
}

/* Recursive function to get the length of a linked list. */
int lengthOf(Cell* list) {
    /* Base case: An empty list has length zero. */
    if (list == nullptr) return 0;

    /* Recursive case: A linked list with at least one cell has length one
     * for that cell, plus the length of whatever remains.
     */
    return 1 + lengthOf(list->next);
}

/* Recursive function to read a linked list from the user. */
Cell* readList() {
    /* See if the user wants to enter more text. */
    string data = getLine("Enter the next item, or the empty string if you're done: ");

    /* If they don't, give back an empty list. */
    if (data == "") return nullptr;

    /* Otherwise, put that data into a linked list cell, followed by whatever the
     * user types in next.
     */
    Cell* result = new Cell;
    result->value = data;
    result->next = readList();
    return result;
}

/* Recursive function to free a linked list. */
void deleteList(Cell* list) {
    /* Base case: If the list is empty, there's nothing to do. */
    if (list == nullptr) return;

    /* Recursive case: Free the rest of the list, then free the first cell.
     * Make sure you understand why the lines have to be in this order.
     */
    deleteList(list->next);
    delete list;
}

int main() {
    Cell* list = readList();

    cout << "List has length " << lengthOf(list) << endl;
    printList(list);
    deleteList(list);

    return 0;
}




