/* File: Subsets.cpp
 *
 * A program to list off all subsets of a master set.
 */
#include <iostream>
#include <string>
#include "set.h"
#include "console.h"
using namespace std;

/* Recursively lists of all subsets of the set elems, given
 * that we've already committed to picking the elements in
 * chosen.
 */
void listSubsetsRec(const Set<int>& elems,
                    const Set<int>& chosen) {
    /* Base case: If elems is empty, we have made all of our choices.
     * Therefore, we should print out what set that produced.
     */
    if (elems.isEmpty()) {
        cout << chosen << endl;
    }
    /* Recursive case: Otherwise, there's at least one element left
     * in the set. We either include that element in our resulting
     * set, or we don't, so we try both options.
     */
    else {
        /* Get some element of the set. */
        int elem = elems.first();

        /* Option 1: Include this element. */
        listSubsetsRec(elems - elem, chosen + elem);

        /* Option 2: Exclude this element. */
        listSubsetsRec(elems - elem, chosen);
    }
}

/* Wrapper function to list subsets. The user provides us the set they
 * care about, and we supply it to listSubsetsRec, passing in an empty
 * set as a second parameter for them.
 */
void listSubsetsOf(const Set<int>& s) {
    listSubsetsRec(s, {});
}

int main() {
    listSubsetsOf({1, 2, 3});
    return 0;
}

