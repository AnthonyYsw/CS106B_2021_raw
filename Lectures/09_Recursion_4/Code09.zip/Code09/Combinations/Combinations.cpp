#include <iostream>
#include "set.h"
#include "console.h"
using namespace std;

Set<Set<string>> combinationsRec(const Set<string>& elems,
                                 int numMoreToPick,
                                 const Set<string>& soFar) {
    /* Base case 1: No more to pick? Then you're done. */
    if (numMoreToPick == 0) {
        return { soFar };
    }
    /* Base case 2: Can't find enough people? Sad times! */
    else if (elems.size() < numMoreToPick) {
        return { };
    }
    /* Recursive case: Pick someone, then either include or exclude. */
    else {
        string elem = elems.first();
        Set<string> remaining = elems - elem;

        /* Option 1: Include this person. */
        auto with = combinationsRec(remaining, numMoreToPick - 1, soFar + elem);

        /* Option 2: Exclude this person. */
        auto without = combinationsRec(remaining, numMoreToPick, soFar);

        return with + without;
    }
}


Set<Set<string>> combinationsOf(const Set<string>& elems, int itemsNeeded) {
    return combinationsRec(elems, itemsNeeded, {});
}

int main() {
    Set<string> usSupremeCourt = {
        "Roberts",
        "Thomas",
        "Breyer",
        "Alito",
        "Sotomayor",
        "Kagan",
        "Gorsuch",
        "Kavanaugh",
        "Barrett"
    };

    Set<Set<string>> combinations = combinationsOf(usSupremeCourt, 5);
    cout << "There are " << combinations.size() << " combinations. They are: " << endl;
    for (Set<string> combination: combinations) {
        cout << combination << endl;
    }
    return 0;
}
