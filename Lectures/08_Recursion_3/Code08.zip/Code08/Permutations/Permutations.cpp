/* File: Permutations.cpp
 *
 * Functions to list off all permutations of a collection of elements.
 */
#include <iostream>
#include <string>
#include "set.h"
#include "console.h"
using namespace std;

/* Recursively lists all permutations of the given string, provided
 * that we've already locked in the partial permutation given in chosen.
 */
void listPermutationsRec(const string& str, const string& chosen) {
    /* Base case: If we've ordered all the characters, print out the
     * result of that ordering.
     */
    if (str == "") {
        cout << chosen << endl;
    }
    /* Otherwise, some character comes next. Try all possibilities for
     * what it could be.
     */
    else {
        for (int i = 0; i < str.size(); i++) {
            string remaining = str.substr(0, i) + str.substr(i + 1);
            listPermutationsRec(remaining, chosen + str[i]);
        }
    }
}

void listPermutationsOf(const string& str) {
    listPermutationsRec(str, "");
}

/* Recursively generate and return all permutations of the given
 * string, given that we've locked in the partial permutation given
 * in chosen.
 */
Set<string> permutationsRec(const string& str, const string& chosen) {
    /* Base case: If we've already selected an ordering for all the
     * characters, the only string we can make is the permutation
     * we've built thus far.
     */
    if (str == "") {
        /* Have to return a set of all options, and the only option here
         * is chosen.
         */
        return { chosen };
    }
    /* Recursive case: Try all possible characters as the next one.
     * writing down what we develop.
     */
    else {
        Set<string> result;
        for (int i = 0; i < str.size(); i++) {
            string remaining = str.substr(0, i) + str.substr(i + 1);
            result += permutationsRec(remaining, chosen + str[i]);
        }    
        return result;
    }
}

Set<string> permutationsOf(const string& str) {
    return permutationsRec(str, "");
}


int main() {
    listPermutationsOf("AHI");
    for (string permutation: permutationsOf("EMU")) {
        cout << permutation << endl;
    }
    return 0;
}
