INITIAL_HANDLER("MazeGUI.cpp")
WINDOW_TITLE("Maze Generator")
