/*************************************************
 * File: LinkedLists.cpp
 *
 * Our very third program using Linked Lists! :-D
 */

#include <iostream>
#include <string>
#include "simpio.h"
#include "console.h"
using namespace std;

/* Type: Cell
 *
 * A cell in a linked list.
 */
struct Cell {
    string value;
    Cell* next;
};

/* From last time! */
void printList(Cell* list) {
    while (list != nullptr) {
        cout << list->value << endl;
        list = list->next;
    }
}

/* From last time! */
void deleteList(Cell* list) {
    while (list != nullptr) {
        Cell* next = list->next;
        delete list;
        list = next;
    }
}

/* Prepends a cell to the front of a linked list. */
void prependTo(Cell*& list, const string& value) {
    Cell* cell  = new Cell;
    cell->value = value;
    cell->next  = list;
    list = cell;
}

/* Slow version of append that works given a pointer to the first cell of the
 * linked list.
 */
//void appendTo(Cell*& list, const string& value) {
//    Cell* cell  = new Cell;
//    cell->value = value;
//    cell->next  = nullptr;
//
//    /* If the list is empty, we are the only cell. */
//    if (list == nullptr) {
//        list = cell;
//    } else {
//        /* Scan to the end of the list. Don't change the list pointer itself, since
//         * otherwise we'll forget where the list is!
//         */
//        Cell* end = list;
//        while (end->next != nullptr) {
//            end = end->next;
//        }
//
//        /* Tack this cell onto the end of the list. */
//        end->next = cell;
//    }
//}

/* Faster version of append that needs both a head and tail pointer. */
void appendTo(Cell*& head, Cell*& tail, const string& value) {
    Cell* cell  = new Cell;
    cell->value = value;
    cell->next  = nullptr;

    /* If the list is empty, this is both the first and last cell. */
    if (head == nullptr) {
        head = tail = cell;
    }
    /* Otherwise, the last cell now points to us, and we're the last cell. */
    else {
        tail->next = cell;
        tail = cell;
    }
}

int main() {
    Cell* head = nullptr;
    Cell* tail = nullptr;

    appendTo(head, tail, "Quokka");
    appendTo(head, tail, "Pudu");
    appendTo(head, tail, "Dikdik");
    appendTo(head, tail, "Gerenuk");

    printList(head);
    deleteList(head);
    return 0;
}


